#include "texteditor.h"


TextEditor::TextEditor(const std::string& filename) : _buffer

TextEditor::~TextEditor() {
    
}

void TextEditor::press_left() {
    
}

void TextEditor::press_right() {
    
}

void TextEditor::press_key(char ch) {
    
}

char TextEditor::retrieve_next_character() {
    
}

char TextEditor::retrieve_character(size_t position) {
    
}
